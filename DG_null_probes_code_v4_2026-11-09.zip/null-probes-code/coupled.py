import numpy as np
from numpy.polynomial import chebyshev as Ch
from scipy.special import jv
tau=1.0
rho0=lambda w: 1/(1+w*w)**2          # |h0(i w)|^2, h0(s)=1/(1+s)^2, m=2
w=np.concatenate([np.linspace(0,50,500001),np.geomspace(50,1e6,200001)[1:]])
def trap(f): return np.trapezoid(f,w)
e2=1+np.cos(w*tau)**2
mu=trap(rho0(w)*e2); k2=np.pi*trap((rho0(w)*e2)**2)
indep=(2*tau/3)*0.5*mu**3/(2*4*k2)    # Theorem 1 constant: liminf delta*G >= indep
print('mu',mu,'||k||^2',k2,'independent: delta*G >=',indep)
def coupled(W,eps=1e-12):
    z=2*W*tau   # approximate cos(2W tau y) on y in [-1,1], y = w/(2W)
    n=0
    while True:
        n+=2
        tail=sum(2*abs(jv(k,z)) for k in range(n+2,n+60,2))
        if tail<eps: break
    c=np.zeros(n+1); c[0]=jv(0,z)
    for k in range(2,n+1,2): c[k]=2*(-1)**(k//2)*jv(k,z)
    N=n+1; m=w<=4*W
    y=w/(2*W); P=np.where(m,Ch.chebval(np.where(m,y,0),c),0.0)
    c2=np.where(m,1/(1+np.where(m,w/W,0)**(2*N)),0.0)
    # beyond 4W: c2*P^2 <= (sum|c|)^2 x^(2n) x^(-2N) <= (sum|c|)^2 4^(-2): add bound to error
    S1=np.sum(np.abs(c)); extra=trap(np.where(m,0,rho0(w)*(1+S1**2/16+2*S1/4)))
    # || S_hat - S* || (operator norm of 2x2 difference), S*=rho0 e e^T, S_hat=rho0 c2 p p^T
    a11=rho0(w)*(c2-1); a12=rho0(w)*(c2*P-np.cos(w*tau)); a22=rho0(w)*(c2*P*P-np.cos(w*tau)**2)
    op=np.abs(a11+a22)/2+np.sqrt(((a11-a22)/2)**2+a12**2)
    return n, 2+N, trap(op)+extra       # state dimension = deg h0 + Butterworth order
s_l=np.array([0.,1.,2.]); dd=abs(s_l[:,None]-s_l[None,:])
lam=lambda G: np.linalg.eigvalsh(np.exp(-G*dd))[0]
Gs=np.geomspace(1e-7,1e3,3000); L=np.array([lam(g) for g in Gs])
def indep_finite(delta):
    B=4/0.5; r=2; best=0
    for eta in np.geomspace(1e-3,3,40):
        ce=np.min(L[Gs<eta]/Gs[Gs<eta]); le=np.min(L[Gs>=eta]); a=mu-r*delta-B*delta/le
        if a<=0: continue
        for T in np.geomspace(1,1e14,300):
            best=max(best,a**3/(2*(B*delta/ce+a/T)*(np.sqrt(k2)+r*delta*np.sqrt(T))**2))
    return best
print(' W   poly n  state dim   L1 bound on all-time error delta   independent need >= ')
for W in [2,4,8,16,32,64]:
    n,dim,d=coupled(W)
    print(f"{W:4d} {n:6d} {dim:8d}   {d:.3e}   {indep_finite(d):,.0f}")
