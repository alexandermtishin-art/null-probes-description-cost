import numpy as np
from scipy.integrate import quad
# kappa = int_0^inf |2cos(pi s/2)/(1-s^2)| ds, split at odd integers where cos vanishes; tail by asymptotic series
def f(s):
    d=1-s*s
    return np.pi/2 if abs(d)<1e-12 else abs(2*np.cos(np.pi*s/2)/d)
S=20001
kap=quad(f,0,1,limit=200)[0]+sum(quad(f,2*j-1,2*j+1,limit=200)[0] for j in range(1,(S+1)//2))
# tail beyond S: |cos| averages 2/pi, integrand ~ (4/pi)/(s^2-1)
kap+= (4/np.pi)*0.5*np.log((S+1)/(S-1))
print('kappa =',kap)
tau=1.0
def Nbound(rho,delta,kmax=10**6):
    thr=2*kap*delta/np.pi; K=0
    for k in range(1,kmax):
        a,b=(k-0.5)*np.pi/tau,(k+0.5)*np.pi/tau
        if quad(lambda w: rho(w)*np.cos(w*tau)**2,a,b,limit=100)[0]<=thr: break
        K=k
    return K
r2=lambda w: 1/(1+w*w)**2
rc1=lambda w: (2/np.pi)/(1+w*w)/(1+np.cos(w*tau)**2)   # bath of Corollary 1, A=lambda=tau=1
for d in [9.9e-4,1.25e-4,1.59e-5,2.05e-6]: print('Table rho0, delta',d,'D >=',Nbound(r2,d))
for d in [1e-3,1e-4,1e-5,1e-6]: print('Corollary-1 bath, delta',d,'D >=',Nbound(rc1,d),' independent (asympt, 2G) >= ',round(2/(24*d)))
ds=np.geomspace(1e-7,1e-1,61); Ns=[Nbound(r2,d) for d in ds]
np.save('universal_curve.npy',np.array([ds,Ns]))
print(list(zip(ds[::10],Ns[::10])))
