import numpy as np, json, sys
sys.path.insert(0,'.')
import io,contextlib
with contextlib.redirect_stdout(io.StringIO()):
    import coupled as C
pts=[]
for W in [2,4,8,16,32,64]:
    n,dim,d=C.coupled(W); pts.append((W,dim,d,C.indep_finite(d)))
ds=np.geomspace(1e-7,1e-2,26); ind=[C.indep_finite(d) for d in ds]
json.dump({'pts':pts,'ds':ds.tolist(),'ind':ind,'asym':C.indep},open('fig_data.json','w'))
print(pts, C.indep)
