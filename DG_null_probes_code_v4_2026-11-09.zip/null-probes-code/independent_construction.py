# Explicit independent positive Lorentzian description of the rotating bath
# rho0=(1+w^2)^-2, tau=1, by dyadic smooth partition + uniform grid + common damping per band.
import numpy as np, sys, json
tau=1.0
rho=lambda w: 1/(1+w*w)**2
k0=lambda s: (np.pi/4)*(1+np.abs(s))*np.exp(-np.abs(s))
def Ktrue(t):
    return k0(t), 0.5*(k0(t-tau)+k0(t+tau)), 0.5*k0(t)+0.25*(k0(t-2*tau)+k0(t+2*tau))
def psi(y): 
    y=np.asarray(y,float); out=np.zeros_like(y); m=y>0; out[m]=np.exp(-1/y[m]); return out
def chi(x): a=psi(2-x); b=psi(x-1); return a/(a+b)
wc=1.0
def phi(b,w):
    if b==0: return chi(w/wc)
    return chi(w/(2**b*wc))-chi(w/(2**(b-1)*wc))
def supp(b): return (0.0 if b==0 else 2**(b-1)*wc, 2**(b+1)*wc)
def opn(a,c,d): return np.abs(a+d)/2+np.sqrt(((a-d)/2)**2+c*c)
def band_kernel(b,t):
    lo,hi=supp(b); w=np.linspace(lo,hi,20001); f=phi(b,w)*rho(w); c=np.cos(w*tau)
    dw=w[1]-w[0]; C=np.cos(np.outer(t,w))
    k11=np.trapezoid(f*C,dx=dw,axis=1); k12=np.trapezoid(f*c*C,dx=dw,axis=1); k22=np.trapezoid(f*c*c*C,dx=dw,axis=1)
    return k11,k12,k22
def build(delta, frac_tail=0.3):
    # bands to keep: dropped tail 2*int_{2^B}^inf rho <= frac_tail*delta
    B=0
    while 2*(1/3)*(2**B*wc)**-3 > frac_tail*delta: B+=1
    bands=list(range(0,B+1))
    info=[]
    tt=np.linspace(0,8*tau+40,4001)
    for b in bands:
        k11,k12,k22=band_kernel(b,tt); n=opn(k11,k12,k22)
        M1=np.max(tt*n); Kinf=np.max(n); L=supp(b)[1]-supp(b)[0]
        info.append(dict(b=b,M1=M1,Kinf=Kinf,L=L))
    X=np.array([d['L']*d['M1'] for d in info]); s=np.sqrt(X)
    dbud=(1-frac_tail)*delta*s/s.sum()
    lines=[]
    for d,db in zip(info,dbud):
        G=db/(2*d['M1'])                              # damping error ~ G*M1 = db/2
        h=2*np.pi*G/(np.log(4*d['Kinf']/db)+G*(4*tau))  # alias ~ 2 Kinf e^{-G(2pi/h-4tau)} <= db/2
        lo,hi=supp(d['b']); j0=int(np.floor(lo/h-0.5)); j1=int(np.ceil(hi/h-0.5))
        wj=(np.arange(max(j0,0),j1+1)+0.5)*h
        wt=h*phi(d['b'],wj)*rho(wj); m=wt>0
        d.update(Gam=G,h=h,n=int(m.sum()))
        lines.append((wj[m],wt[m],np.full(m.sum(),G)))
    w=np.concatenate([l[0] for l in lines]); a=np.concatenate([l[1] for l in lines]); g=np.concatenate([l[2] for l in lines])
    return w,a,g,info
def Khat(t,w,a,g,chunk=200000):
    out=[np.zeros_like(t) for _ in range(3)]; c=np.cos(w*tau)
    step=max(1,chunk//len(w))
    for i in range(0,len(t),step):
        ts=t[i:i+step]; E=np.exp(-np.outer(ts,g))*np.cos(np.outer(ts,w))
        out[0][i:i+step]=E@a; out[1][i:i+step]=E@(a*c); out[2][i:i+step]=E@(a*c*c)
    return out
if __name__=='__main__':
    delta=float(sys.argv[1])
    w,a,g,info=build(delta)
    G=len(w)
    # evaluation grid: dense early window + windows around first two aliases of every band + coarse scan
    pts=[np.linspace(0,12,24001)]
    for d in info:
        for nrep in (1,2):
            c0=2*np.pi*nrep/d['h']
            pts.append(np.linspace(max(0,c0-5*tau-20/2**d['b']),c0+5*tau+20/2**d['b'],8001))
    Tend=max(4*np.pi/d['h'] for d in info)+20
    pts.append(np.linspace(0,Tend,200001))
    t=np.unique(np.concatenate(pts))
    k=Khat(t,w,a,g); kt=Ktrue(t)
    err=opn(k[0]-kt[0],k[1]-kt[1],k[2]-kt[2])
    i=np.argmax(err)
    print(json.dumps(dict(delta_target=delta,G=G,sup_err=float(err.max()),t_at=float(t[i]),
        bands=[(d['b'],d['n'],round(d['Gam'],6),round(d['h'],7)) for d in info])))
