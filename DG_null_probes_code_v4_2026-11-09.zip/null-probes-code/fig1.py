import numpy as np, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['Liberation Serif'],'mathtext.fontset':'stix','font.size':10,
 'axes.linewidth':0.7,'xtick.direction':'in','ytick.direction':'in','xtick.major.width':0.7,'ytick.major.width':0.7})
D=json.load(open('fig_data.json')); tau=1.0
w=np.linspace(0,14,1400); r0=1/(1+w*w)**2; c=np.cos(w*tau)
fig,ax=plt.subplots(1,2,figsize=(7.0,3.6))
a=ax[0]
th=np.arctan(c)/(np.pi/4)
a.fill_between(w*tau,0,r0,color='0.85',lw=0,label=r'$\rho_0(\omega)/\rho_0(0)$')
a.plot(w*tau,th,'k-',lw=1.4,label=r'$\theta(\omega)/(\pi/4)$')
a.axhline(0,color='0.6',lw=0.6,zorder=0)
a.set_xlabel(r'$\omega\tau$'); a.set_xlim(0,14); a.set_ylim(-1.15,1.45)
a.legend(frameon=False,loc='upper right',ncol=2,fontsize=8.5,columnspacing=1.0); a.text(0.03,0.05,'(a)',transform=a.transAxes)
b=ax[1]
ds=np.array(D['ds']); ind=np.array(D['ind']); P=np.array(D['pts'])
m=2*ind>1
b.loglog(1/ds[m],2*ind[m],'k-',lw=1.4,label='independent lines, lower bound (7)')
b.loglog(1/ds,2*D['asym']/ds,'k:',lw=1.0,label=r'asymptote $2c/\delta$')
E=json.load(open('fig_data2.json'))
IC=np.array(E['indep_construction']); b.loglog(1/IC[:,0],2*IC[:,1],'ks',ms=4.5,mfc='0.6',mew=0.8,label='independent lines, construction (Theorem 2)')
b.loglog(1/P[:,2],P[:,1],'ko',ms=4.5,mfc='white',mew=1.1,label='coupled network (Theorem 5)')
ud=np.array(E['universal']['delta']); uN=np.array(E['universal']['N']); mm=uN>=1
b.step(1/ud[mm][::-1],uN[mm][::-1],'k-.',lw=1.0,where='post',label='any finite realization (Theorem 6)')
b.set_xlabel(r'$1/\delta$'); b.set_ylabel('real state dimension'); b.set_xlim(1e1,1e7); b.set_ylim(0.8,2e5)
h,l=b.get_legend_handles_labels(); fig.legend(h,l,frameon=False,loc='lower center',ncol=2,fontsize=8.5,handlelength=2.4,bbox_to_anchor=(0.5,0.0)); b.text(0.95,0.05,'(b)',transform=b.transAxes,ha='right')
fig.tight_layout(rect=(0,0.17,1,1)); fig.savefig('fig1.png',dpi=600); fig.savefig('fig1.pdf')
