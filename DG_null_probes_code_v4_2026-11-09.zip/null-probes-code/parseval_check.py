import numpy as np, sys
sys.argv=['x','1e-2']
import independent_construction as C
w,a,g,info=C.build(1e-2)
tau=1.0; kap=3.703874103964955
c=np.cos(w*tau)
# spectral density of the lines, (1,2) entry, on [0, 12]
om=np.linspace(0,12,240001)
R12h=np.zeros_like(om)
for i in range(0,len(w),200):
    ww=w[i:i+200]; gg=g[i:i+200]; aa=(a*c)[i:i+200]
    L=(gg/((om[:,None]-ww)**2+gg**2)+gg/((om[:,None]+ww)**2+gg**2))/np.pi
    R12h+=L@aa
R12=C.rho(om)*np.cos(om*tau)
t=np.unique(np.concatenate([np.linspace(0,12,24001),np.linspace(0,4*np.pi/min(d['h'] for d in info)+20,200001)]))
k=C.Khat(t,w,a,g); kt=C.Ktrue(t); e12=np.max(np.abs(k[1]-kt[1]))
print('sup|K12hat-K12| =',e12,' rhs (2/pi) kappa sup =',2*kap*e12/np.pi)
for kk in range(1,4):
    m=(om>=(kk-0.5)*np.pi/tau)&(om<=(kk+0.5)*np.pi/tau)
    gk=np.abs(np.cos(om[m]*tau))
    lhs=abs(np.trapezoid((R12h[m]-R12[m])*gk,om[m])); true=np.trapezoid(R12[m]*gk,om[m])
    print(f'k={kk}: |int (R12hat-R12) g_k| = {lhs:.3e}  <= {2*kap*e12/np.pi:.3e} ? {lhs<=2*kap*e12/np.pi};  int R12 g_k = {true:+.3e}')
