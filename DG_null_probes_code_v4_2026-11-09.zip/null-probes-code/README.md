# Null probes and the cost of finite descriptions of correlated baths: code

Scripts behind every number in the manuscript "Null probes certify the cost of finite descriptions of correlated baths" (A. M. Tishin). Python 3.10 or later with NumPy 2, SciPy.

| Script | What it computes | Manuscript |
|---|---|---|
| `check_A.py` | Random test of Lemma 1 (minimum ratio 1.0000) and the small-width slope of Lemma 2 for lags 0, τ, 2τ (c_s = 2τ/3) | Section 3 |
| `cert.py` | Finite certificate of Corollary 2 for the rotating bath (G ≥ 15, 185, 1985 at δ = 1e-3, 1e-4, 1e-5) | Section 5 |
| `bump.py` | One rotating bump replaced by one fixed-direction line (Theorem 4 example) | Section 5 |
| `coupled.py` | Coupled realizations of Theorem 5 and the independent-line bound (7); Table 1 | Section 6 |
| `bound13_check.py` | Evaluation of the explicit bound (13) for the rows of Table 1 | Section 6 |
| `independent_construction.py` | Explicit independent positive description of Theorem 2 for ρ0=(1+ω²)⁻², τ=1; run with the target error (1e-2, 3e-3, 1e-3) to get G = 1924, 7867, 27082 and the directly evaluated all-time errors | Section 4 |
| `universal_bound.py` | κ = 3.7039 and the lower bound N_τ(δ) of Theorem 6 for both baths (Table 1 last column, Section 6 numbers) | Section 6 |
| `parseval_check.py` | Numerical check of the inequality used in the proof of Theorem 6 | Section 6 |
| `fig_data.py`, `fig1.py`, `fig_data2.json` | Data and plot for Fig. 1: coupling angle of the rotating bath and state dimension of independent and coupled descriptions against 1/δ | Sections 2 and 6 |

Run each script from this folder, for example `python coupled.py`.
