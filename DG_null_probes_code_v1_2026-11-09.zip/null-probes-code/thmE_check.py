import numpy as np
from scipy.special import jv
tau=1.0; A=np.pi/4
T=lambda W: 0.5*(np.pi/2-np.arctan(W)-W/(1+W*W))
actual={8:(38,9.935e-04),16:(60,1.252e-04),32:(100,1.594e-05),64:(172,2.047e-06)}
for W,(n_used,err) in actual.items():
    z=2*W*tau
    eps_n=2*sum(abs(jv(nu,z)) for nu in range(n_used+2,n_used+400,2))
    bound=3.1*eps_n*A+2*4.0**(-(n_used+1))*A+2*T(W/2)+(2+3*eps_n)*T(W)+(3+(1+np.sqrt(n_used))**2/4)*T(2*W)
    n_thm=int(np.ceil(2*np.e*W*tau+np.log2(4/1e-12)))
    print(f"W={W}: n={n_used} eps_n={eps_n:.1e}  theorem bound={bound:.3e}  actual L1={err:.3e}  ok={bound>=err}   n from theorem formula={n_thm}")
