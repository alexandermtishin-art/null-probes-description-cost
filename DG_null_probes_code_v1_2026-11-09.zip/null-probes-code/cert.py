import numpy as np
from scipy.optimize import minimize_scalar
s=np.array([0.,1.,2.]); d=abs(s[:,None]-s[None,:])
lam=lambda G: np.linalg.eigvalsh(np.exp(-G*d))[0]
Gs=np.geomspace(1e-6,1e3,4000); L=np.array([lam(g) for g in Gs])
def c_eta(eta): m=Gs<eta; return np.min(L[m]/Gs[m])
def lam_eta(eta): m=Gs>=eta; return np.min(L[m])
sig2=0.5; suma=2.0; B=suma**2/sig2; r=2; mu=1.0; rho=2/np.pi; Q2=np.pi*rho*mu
def cert(delta):
    best=0
    for eta in np.geomspace(1e-3,3,60):
        ce,le=c_eta(eta),lam_eta(eta)
        a=mu-r*delta-B*delta/le
        if a<=0: continue
        b=B*delta/ce
        for T in np.geomspace(1,1e12,400):
            G=a**3/(2*(b+a/T)*(np.sqrt(Q2)+r*delta*np.sqrt(T))**2)
            best=max(best,G)
    return best
for delta in [1e-2,1e-3,1e-4,1e-5,1e-6]:
    g=cert(delta); print(f"delta={delta:.0e}  certified G >= {g:.3f}   delta*G={delta*g:.4f}   asymptotic 1/48={1/48:.4f}")
print('c_s check', c_eta(1e-4))
