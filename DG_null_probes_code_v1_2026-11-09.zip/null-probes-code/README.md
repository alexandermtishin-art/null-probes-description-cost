# Null probes and the cost of finite descriptions of correlated baths: code

Scripts behind every number in the manuscript "Null probes certify the cost of finite descriptions of correlated baths" (A. M. Tishin). Python 3.10 or later with NumPy 2, SciPy.

| Script | What it computes | Manuscript |
|---|---|---|
| `check_A.py` | Random test of Lemma 1 (minimum ratio 1.0000) and the small-width slope of Lemma 2 for lags 0, τ, 2τ (c_s = 2τ/3) | Section 3 |
| `cert.py` | Finite certificate of Theorem 3 for the rotating bath (G ≥ 15, 185, 1985 at δ = 1e-3, 1e-4, 1e-5) | Section 5 |
| `bump.py` | One rotating bump replaced by one fixed-direction line (Theorem 4 example) | Section 5 |
| `coupled.py` | Coupled realizations of Theorem 5 and the independent-line bound (7); Table 1 | Section 6 |
| `thmE_check.py` | Evaluation of the explicit bound (13) for the rows of Table 1 | Section 6 |

Run each script from this folder, for example `python coupled.py`.
