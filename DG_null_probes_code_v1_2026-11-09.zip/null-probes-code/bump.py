import numpy as np
tau=1.0; w0=0.7
def uu(w):
    c=np.cos(w*tau); n=1+c*c
    return np.stack([np.stack([1/n,c/n]),np.stack([c/n,c*c/n])])
for eps in [1e-1,3e-2,1e-2,3e-3,1e-3]:
    x=np.linspace(-200*eps**0.5-1,200*eps**0.5+1,2000001)  # wide window
    P=eps/(np.pi*(x*x+eps*eps)); D=uu(w0+x)-uu(np.array(w0))[:,:,None] if False else uu(w0+x)-uu(np.array([w0]))[:,:,0][:,:,None]
    t=np.linspace(0,60,301); err=0
    for tt in t:
        E=np.trapezoid(P*D*np.cos((w0+x)*tt),x,axis=-1); err=max(err,np.max(np.abs(np.linalg.eigvalsh(E))))
    tail=1-np.trapezoid(P,x)
    print(f"eps={eps:.0e} sup err={err:.4e} err/(eps ln(1/eps))={err/(eps*np.log(1/eps)):.3f} (window tail {tail:.1e})")
