import numpy as np
rng=np.random.default_rng(1)
# (i) line contribution V_j = sum a_i^T H(s_i-s_k) a_k for H=vv^T e^{-G|t|}cos(w t) >= lambda_min(E_G)|Av|^2
def V_line(a,s,v,G,w):
    al=a@v; d=s[:,None]-s[None,:]
    return al@(np.exp(-G*abs(d))*np.cos(w*d))@al
def lam(s,G):
    d=s[:,None]-s[None,:]; return np.linalg.eigvalsh(np.exp(-G*abs(d)))[0]
worst=1e9
for trial in range(20000):
    m=rng.integers(2,6); q=rng.integers(1,4)
    s=np.sort(rng.uniform(0,5,m)); a=rng.normal(size=(m,q)); v=rng.normal(size=q)
    G=10**rng.uniform(-4,1); w=rng.uniform(-50,50)
    r=V_line(a,s,v,G,w)/(lam(s,G)*np.sum((a@v)**2))
    worst=min(worst,r)
print('min ratio V_line/(lam*|Av|^2) =',worst,'(must be >=1)')
# (ii) small-Gamma slope for lags {0,1,2}
s=np.array([0.,1.,2.])
d=abs(s[:,None]-s[None,:]); J=np.ones((3,3))
Q=np.linalg.qr(np.vstack([np.ones(3),[1,0,-1],[1,-2,1]]).T)[0][:,1:]
cs=np.linalg.eigvalsh(Q.T@(-d)@Q)[0]
for G in [1e-1,1e-2,1e-3,1e-4]: print('Gamma',G,'lam/Gamma',lam(s,G)/G)
print('predicted slope lambda_min(-D on 1perp)=',cs)
